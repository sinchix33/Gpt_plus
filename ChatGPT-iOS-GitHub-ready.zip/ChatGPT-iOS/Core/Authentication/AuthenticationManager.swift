import Foundation
import SwiftUI
import AuthenticationServices

// MARK: - Authentication State & Session Manager

public enum AuthState: Equatable {
    case loading
    case unauthenticated
    case authenticated(UserSession)
}

@MainActor
@Observable
public final class AuthenticationManager: NSObject, ASWebAuthenticationPresentationContextProviding {
    public static let shared = AuthenticationManager()

    public var authState: AuthState = .loading
    public var currentUser: UserSession?
    public var activeAccount: AccountInfo?
    public var isAuthenticating: Bool = false
    public var authError: String?

    public var isAuthenticated: Bool {
        if case .authenticated = authState {
            return true
        }
        return false
    }

    private let networkClient: OpenAINetworkClient
    private var webAuthSession: ASWebAuthenticationSession?

    public init(networkClient: OpenAINetworkClient = .shared) {
        self.networkClient = networkClient
        super.init()
    }

    // MARK: - Restore Session on App Launch

    public func restoreSession() async {
        authState = .loading
        authError = nil

        guard let token = await KeychainManager.shared.get(key: .accessToken), !token.isEmpty else {
            authState = .unauthenticated
            return
        }

        // Verify existing session against backend account check
        do {
            let accountCheck: AccountCheckResponse = try await networkClient.execute(.accountCheck)
            let primaryAccount = accountCheck.accounts.first(where: { $0.id == accountCheck.activeAccountId }) ?? accountCheck.accounts.first

            self.activeAccount = primaryAccount

            // Restore user session
            let savedEmail = UserDefaults.standard.string(forKey: "openai_user_email")
            let savedName = UserDefaults.standard.string(forKey: "openai_user_name")
            let planString = primaryAccount?.planType.rawValue ?? "free"

            let session = UserSession(
                accountUserId: primaryAccount?.id ?? "user_authenticated",
                accountId: accountCheck.activeAccountId ?? primaryAccount?.id ?? "account_default",
                email: savedEmail,
                name: savedName,
                picture: nil,
                planType: planString
            )

            self.currentUser = session
            self.authState = .authenticated(session)
        } catch {
            // Check if token can be refreshed
            do {
                let refreshed = try await networkClient.refreshTokenIfNeeded()
                if refreshed {
                    await restoreSession()
                    return
                }
            } catch {
                // Refresh failed
            }

            // If offline, preserve cached session if available; otherwise unauthenticate
            if let savedEmail = UserDefaults.standard.string(forKey: "openai_user_email") {
                let cachedSession = UserSession(
                    accountUserId: "cached_user",
                    accountId: "cached_account",
                    email: savedEmail,
                    name: UserDefaults.standard.string(forKey: "openai_user_name"),
                    picture: nil,
                    planType: UserDefaults.standard.string(forKey: "openai_cached_plan") ?? "free"
                )
                self.currentUser = cachedSession
                self.authState = .authenticated(cachedSession)
            } else {
                await KeychainManager.shared.clearAll()
                self.authState = .unauthenticated
            }
        }
    }

    // MARK: - Sign in with Token / Session Key

    public func signInWithToken(_ token: String, email: String? = nil, name: String? = nil) async -> Bool {
        let cleanToken = token.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !cleanToken.isEmpty else {
            self.authError = "Please enter a valid session token or API key."
            return false
        }

        isAuthenticating = true
        authError = nil

        do {
            // Save token to Keychain first for the check request
            try await KeychainManager.shared.save(key: .accessToken, string: cleanToken)

            // Validate against backend account check endpoint
            let accountCheck: AccountCheckResponse = try await networkClient.execute(.accountCheck)
            let primaryAccount = accountCheck.accounts.first(where: { $0.id == accountCheck.activeAccountId }) ?? accountCheck.accounts.first

            self.activeAccount = primaryAccount

            let userEmail = email ?? (cleanToken.hasPrefix("ey") ? decodeEmailFromJWT(cleanToken) : nil) ?? "ChatGPT User"
            let userName = name ?? "ChatGPT Member"
            let planString = primaryAccount?.planType.rawValue ?? (primaryAccount?.hasActiveSubscription == true ? "plus" : "free")

            UserDefaults.standard.set(userEmail, forKey: "openai_user_email")
            UserDefaults.standard.set(userName, forKey: "openai_user_name")
            UserDefaults.standard.set(planString, forKey: "openai_cached_plan")

            let session = UserSession(
                accountUserId: primaryAccount?.id ?? UUID().uuidString,
                accountId: accountCheck.activeAccountId ?? primaryAccount?.id ?? UUID().uuidString,
                email: userEmail,
                name: userName,
                picture: nil,
                planType: planString
            )

            self.currentUser = session
            self.authState = .authenticated(session)
            self.isAuthenticating = false
            return true
        } catch {
            // Revert invalid token from Keychain
            await KeychainManager.shared.delete(key: .accessToken)
            self.isAuthenticating = false
            self.authError = "Authentication failed: \(error.localizedDescription). Please verify your token."
            return false
        }
    }

    // MARK: - Sign in with Web OAuth (ASWebAuthenticationSession)

    public func startWebAuth() {
        isAuthenticating = true
        authError = nil

        let authUrlString = "https://auth.openai.com/api/accounts/authorize?client_id=pvd_chatgpt_mobile_client&audience=https%3A%2F%2Fapi.openai.com%2Fv1&redirect_uri=com.openai.chatgpt%3A%2F%2Fauth0.openai.com%2Fios%2Fcom.openai.chatgpt%2Fcallback&scope=openid%20profile%20email%20offline_access&response_type=code"

        guard let authUrl = URL(string: authUrlString) else {
            isAuthenticating = false
            authError = "Invalid authorization server URL."
            return
        }

        webAuthSession = ASWebAuthenticationSession(
            url: authUrl,
            callbackURLScheme: "com.openai.chatgpt"
        ) { [weak self] callbackUrl, error in
            Task { @MainActor [weak self] in
                guard let self = self else { return }
                self.isAuthenticating = false

                if let error = error as? ASWebAuthenticationSessionError, error.code == .canceledLogin {
                    return
                }

                if let error = error {
                    self.authError = "Web sign-in error: \(error.localizedDescription)"
                    return
                }

                guard let callbackUrl = callbackUrl,
                      let components = URLComponents(url: callbackUrl, resolvingAgainstBaseURL: false),
                      let code = components.queryItems?.first(where: { $0.name == "code" })?.value else {
                    self.authError = "Authorization callback was missing the exchange code."
                    return
                }

                await self.exchangeCodeForTokens(code: code)
            }
        }

        webAuthSession?.presentationContextProvider = self
        webAuthSession?.prefersEphemeralWebBrowserSession = false
        webAuthSession?.start()
    }

    private func exchangeCodeForTokens(code: String) async {
        isAuthenticating = true
        do {
            let tokenUrl = URL(string: "https://auth.openai.com/oauth/token")!
            var request = URLRequest(url: tokenUrl)
            request.httpMethod = "POST"
            request.setValue("application/json", forHTTPHeaderField: "Content-Type")

            let tokenReq = TokenRequest.authorizationCode(
                code: code,
                clientId: "pvd_chatgpt_mobile_client",
                redirectUri: "com.openai.chatgpt://auth0.openai.com/ios/com.openai.chatgpt/callback",
                codeVerifier: "pkce_verifier_chatgpt_ios"
            )
            request.httpBody = try JSONEncoder().encode(tokenReq)

            let (data, response) = try await URLSession.shared.data(for: request)
            guard let httpResponse = response as? HTTPURLResponse, (200...299).contains(httpResponse.statusCode) else {
                let errText = String(data: data, encoding: .utf8) ?? "Token exchange failed"
                throw SSEError.serverError(statusCode: (response as? HTTPURLResponse)?.statusCode ?? 400, message: errText)
            }

            let tokenResp = try JSONDecoder().decode(TokenResponse.self, from: data)
            _ = await signInWithToken(tokenResp.accessToken)
        } catch {
            isAuthenticating = false
            self.authError = "Token exchange failed: \(error.localizedDescription)"
        }
    }

    // MARK: - Sign Out

    public func signOut() async {
        await KeychainManager.shared.clearAll()
        UserDefaults.standard.removeObject(forKey: "openai_user_email")
        UserDefaults.standard.removeObject(forKey: "openai_user_name")
        UserDefaults.standard.removeObject(forKey: "openai_cached_plan")

        currentUser = nil
        activeAccount = nil
        authError = nil
        authState = .unauthenticated
    }

    // MARK: - ASWebAuthenticationPresentationContextProviding

    public func presentationAnchor(for session: ASWebAuthenticationSession) -> ASPresentationAnchor {
        guard let windowScene = UIApplication.shared.connectedScenes.first as? UIWindowScene,
              let window = windowScene.windows.first(where: { $0.isKeyWindow }) else {
            return ASPresentationAnchor()
        }
        return window
    }

    private func decodeEmailFromJWT(_ jwt: String) -> String? {
        let parts = jwt.split(separator: ".")
        guard parts.count >= 2 else { return nil }
        var base64 = String(parts[1])
            .replacingOccurrences(of: "-", with: "+")
            .replacingOccurrences(of: "_", with: "/")
        while base64.count % 4 != 0 {
            base64.append("=")
        }
        guard let payloadData = Data(base64Encoded: base64),
              let json = try? JSONSerialization.jsonObject(with: payloadData) as? [String: Any] else {
            return nil
        }
        return json["email"] as? String ?? json["https://api.openai.com/profile"] as? String
    }
}
