import Foundation
import SwiftUI
import AuthenticationServices
import CryptoKit

// MARK: - OAuth & Authentication Configuration

public struct OAuthConfig: Sendable {
    /// The registered Google OAuth 2.0 Client ID (from Google Cloud Console).
    public var googleClientId: String?

    /// The exact redirect URI / reversed client ID scheme registered for Google OAuth.
    public var googleRedirectUri: String?

    /// Optional custom authentication backend URL for exchanging Google tokens.
    public var authBackendUrl: URL?

    public init(
        googleClientId: String? = nil,
        googleRedirectUri: String? = nil,
        authBackendUrl: URL? = nil
    ) {
        self.googleClientId = googleClientId
        self.googleRedirectUri = googleRedirectUri
        self.authBackendUrl = authBackendUrl
    }
}

// MARK: - Authentication State & Session Manager

public enum AuthState: Equatable {
    case loading
    case unauthenticated
    case authenticated(UserSession)
}

@MainActor
@Observable
public final class AuthenticationManager: NSObject, ASWebAuthenticationPresentationContextProviding {
    public static let shared = AuthenticationManager()

    public var authState: AuthState = .loading
    public var currentUser: UserSession?
    public var activeAccount: AccountInfo?
    public var isAuthenticating: Bool = false
    public var authError: String?

    /// Active OAuth configuration
    public var oauthConfig: OAuthConfig = OAuthConfig()

    public var isAuthenticated: Bool {
        if case .authenticated = authState {
            return true
        }
        return false
    }

    private let networkClient: OpenAINetworkClient
    private var webAuthSession: ASWebAuthenticationSession?

    // Stored PKCE & State values for verification
    private var currentCodeVerifier: String?
    private var currentExpectedState: String?

    public init(networkClient: OpenAINetworkClient = .shared) {
        self.networkClient = networkClient
        super.init()

        // Load saved Google Client ID if previously configured
        if let savedGoogleClientId = UserDefaults.standard.string(forKey: "google_oauth_client_id"), !savedGoogleClientId.isEmpty {
            self.oauthConfig.googleClientId = savedGoogleClientId
            self.oauthConfig.googleRedirectUri = "\(savedGoogleClientId):/oauth2redirect"
        }
        if let savedBackend = UserDefaults.standard.string(forKey: "google_auth_backend_url"), let url = URL(string: savedBackend) {
            self.oauthConfig.authBackendUrl = url
        }
    }

    // MARK: - Restore Session on App Launch

    public func restoreSession() async {
        authState = .loading
        authError = nil

        guard let token = await KeychainManager.shared.get(key: .accessToken), !token.isEmpty else {
            authState = .unauthenticated
            return
        }

        // 1. If stored credential is an OpenAI Platform API Key (sk-...)
        if token.hasPrefix("sk-") {
            let savedName = UserDefaults.standard.string(forKey: "openai_user_name") ?? "OpenAI Developer"
            let session = UserSession(
                accountUserId: "api_key_user",
                accountId: "api_key_account",
                email: "API Key (\(token.prefix(7))...)",
                name: savedName,
                picture: nil,
                planType: "Developer API"
            )
            self.currentUser = session
            self.authState = .authenticated(session)
            return
        }

        // 2. Otherwise verify ChatGPT session token against backend account check
        do {
            let accountCheck: AccountCheckResponse = try await networkClient.execute(.accountCheck)
            let primaryAccount = accountCheck.accounts.first(where: { $0.id == accountCheck.activeAccountId }) ?? accountCheck.accounts.first

            self.activeAccount = primaryAccount

            let savedEmail = UserDefaults.standard.string(forKey: "openai_user_email")
            let savedName = UserDefaults.standard.string(forKey: "openai_user_name")
            let planString = primaryAccount?.planType.rawValue ?? (primaryAccount?.hasActiveSubscription == true ? "plus" : "free")

            let session = UserSession(
                accountUserId: primaryAccount?.id ?? "user_authenticated",
                accountId: accountCheck.activeAccountId ?? primaryAccount?.id ?? "account_default",
                email: savedEmail ?? "ChatGPT Subscriber",
                name: savedName ?? "ChatGPT User",
                picture: nil,
                planType: planString
            )

            self.currentUser = session
            self.authState = .authenticated(session)
        } catch {
            // Attempt token refresh
            do {
                let refreshed = try await networkClient.refreshTokenIfNeeded()
                if refreshed {
                    await restoreSession()
                    return
                }
            } catch {
                // Refresh failed
            }

            // If offline, preserve cached session if available; otherwise unauthenticate
            if let savedEmail = UserDefaults.standard.string(forKey: "openai_user_email") {
                let cachedSession = UserSession(
                    accountUserId: "cached_user",
                    accountId: "cached_account",
                    email: savedEmail,
                    name: UserDefaults.standard.string(forKey: "openai_user_name") ?? "ChatGPT User",
                    picture: nil,
                    planType: UserDefaults.standard.string(forKey: "openai_cached_plan") ?? "free"
                )
                self.currentUser = cachedSession
                self.authState = .authenticated(cachedSession)
            } else {
                await KeychainManager.shared.clearAll()
                self.authState = .unauthenticated
            }
        }
    }

    // MARK: - Sign in with OpenAI API Key (Live Validation against api.openai.com)

    public func signInWithApiKey(_ apiKey: String, name: String? = nil) async -> Bool {
        let cleanKey = apiKey.trimmingCharacters(in: .whitespacesAndNewlines)
        guard cleanKey.hasPrefix("sk-") else {
            self.authError = "Invalid OpenAI API key format. Official OpenAI API keys begin with 'sk-' or 'sk-proj-'."
            isAuthenticating = false
            return false
        }

        isAuthenticating = true
        authError = nil

        do {
            // Live validation against OpenAI Platform API
            _ = try await networkClient.validateApiKey(cleanKey)

            // Save key to Keychain
            try await KeychainManager.shared.save(key: .accessToken, string: cleanKey)

            let userName = name ?? "OpenAI Developer"
            UserDefaults.standard.set("OpenAI Platform Key", forKey: "openai_user_email")
            UserDefaults.standard.set(userName, forKey: "openai_user_name")
            UserDefaults.standard.set("developer_api", forKey: "openai_cached_plan")

            let session = UserSession(
                accountUserId: "api_key_user",
                accountId: "api_key_account",
                email: "API Key (\(cleanKey.prefix(7))...)",
                name: userName,
                picture: nil,
                planType: "Developer API"
            )

            self.currentUser = session
            self.authState = .authenticated(session)
            self.isAuthenticating = false
            return true
        } catch {
            await KeychainManager.shared.delete(key: .accessToken)
            self.isAuthenticating = false
            self.authError = error.localizedDescription
            return false
        }
    }

    // MARK: - Sign in with ChatGPT Session Token (accessToken from chatgpt.com/api/auth/session)

    public func signInWithToken(_ token: String, email: String? = nil, name: String? = nil) async -> Bool {
        let cleanToken = token.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !cleanToken.isEmpty else {
            self.authError = "Please enter a valid session token."
            return false
        }

        if cleanToken.hasPrefix("sk-") {
            return await signInWithApiKey(cleanToken, name: name)
        }

        isAuthenticating = true
        authError = nil

        do {
            // Save session token to Keychain
            try await KeychainManager.shared.save(key: .accessToken, string: cleanToken)

            // Validate against backend account check endpoint
            let accountCheck: AccountCheckResponse = try await networkClient.execute(.accountCheck)
            let primaryAccount = accountCheck.accounts.first(where: { $0.id == accountCheck.activeAccountId }) ?? accountCheck.accounts.first

            self.activeAccount = primaryAccount

            let userEmail = email ?? (cleanToken.hasPrefix("ey") ? decodeEmailFromJWT(cleanToken) : nil) ?? "ChatGPT Subscriber"
            let userName = name ?? "ChatGPT Member"
            let planString = primaryAccount?.planType.rawValue ?? (primaryAccount?.hasActiveSubscription == true ? "plus" : "free")

            UserDefaults.standard.set(userEmail, forKey: "openai_user_email")
            UserDefaults.standard.set(userName, forKey: "openai_user_name")
            UserDefaults.standard.set(planString, forKey: "openai_cached_plan")

            let session = UserSession(
                accountUserId: primaryAccount?.id ?? UUID().uuidString,
                accountId: accountCheck.activeAccountId ?? primaryAccount?.id ?? UUID().uuidString,
                email: userEmail,
                name: userName,
                picture: nil,
                planType: planString
            )

            self.currentUser = session
            self.authState = .authenticated(session)
            self.isAuthenticating = false
            return true
        } catch {
            await KeychainManager.shared.delete(key: .accessToken)
            self.isAuthenticating = false
            self.authError = "Session token validation failed: \(error.localizedDescription).\n\nPlease verify that your accessToken is unexpired from https://chatgpt.com/api/auth/session."
            return false
        }
    }

    // MARK: - Real Google OAuth 2.0 Sign-In (ASWebAuthenticationSession with PKCE RFC 7636)

    public func startGoogleAuth(customClientId: String? = nil, customBackendUrl: URL? = nil) {
        authError = nil

        let clientId = customClientId ?? oauthConfig.googleClientId ?? UserDefaults.standard.string(forKey: "google_oauth_client_id")

        guard let clientId = clientId, !clientId.isEmpty else {
            self.authError = "Google OAuth Client ID is required. Please configure your Google Client ID to sign in with Google."
            return
        }

        // Save Google Client ID for future sessions
        UserDefaults.standard.set(clientId, forKey: "google_oauth_client_id")
        self.oauthConfig.googleClientId = clientId

        if let backendUrl = customBackendUrl {
            UserDefaults.standard.set(backendUrl.absoluteString, forKey: "google_auth_backend_url")
            self.oauthConfig.authBackendUrl = backendUrl
        }

        isAuthenticating = true

        // Generate RFC 7636 PKCE Parameters
        let verifier = generateCodeVerifier()
        let challenge = generateCodeChallenge(from: verifier)
        let state = generateRandomState()

        self.currentCodeVerifier = verifier
        self.currentExpectedState = state

        // The standard redirect URI for Google iOS OAuth is the reversed client ID:
        let redirectUri = "\(clientId):/oauth2redirect"
        let callbackScheme = clientId

        var components = URLComponents(string: "https://accounts.google.com/o/oauth2/v2/auth")!
        components.queryItems = [
            URLQueryItem(name: "client_id", value: clientId),
            URLQueryItem(name: "redirect_uri", value: redirectUri),
            URLQueryItem(name: "response_type", value: "code"),
            URLQueryItem(name: "scope", value: "openid profile email"),
            URLQueryItem(name: "code_challenge", value: challenge),
            URLQueryItem(name: "code_challenge_method", value: "S256"),
            URLQueryItem(name: "state", value: state)
        ]

        guard let authUrl = components.url else {
            isAuthenticating = false
            authError = "Failed to construct Google OAuth authorization URL."
            return
        }

        webAuthSession = ASWebAuthenticationSession(
            url: authUrl,
            callbackURLScheme: callbackScheme
        ) { [weak self] callbackUrl, error in
            Task { @MainActor [weak self] in
                guard let self = self else { return }
                self.isAuthenticating = false

                if let error = error as? ASWebAuthenticationSessionError, error.code == .canceledLogin {
                    return
                }

                if let error = error {
                    self.authError = "Google sign-in was cancelled or encountered an error: \(error.localizedDescription)"
                    return
                }

                guard let callbackUrl = callbackUrl,
                      let urlComponents = URLComponents(url: callbackUrl, resolvingAgainstBaseURL: false) else {
                    self.authError = "Invalid callback URL received from Google."
                    return
                }

                let returnedState = urlComponents.queryItems?.first(where: { $0.name == "state" })?.value
                guard returnedState == self.currentExpectedState else {
                    self.authError = "Google OAuth security check failed: state parameter mismatch (potential CSRF)."
                    return
                }

                if let err = urlComponents.queryItems?.first(where: { $0.name == "error" })?.value {
                    self.authError = "Google authentication error: \(err)"
                    return
                }

                guard let code = urlComponents.queryItems?.first(where: { $0.name == "code" })?.value else {
                    self.authError = "Google authorization callback was missing the exchange code."
                    return
                }

                if let backendUrl = self.oauthConfig.authBackendUrl {
                    await self.exchangeGoogleCodeForTokens(code: code, verifier: verifier, backendUrl: backendUrl)
                } else {
                    // Google returned an authorized code successfully via provider flow
                    self.authError = "Google authentication successful! Authorization code received. To convert this into an active ChatGPT session, a token exchange backend endpoint is required."
                }
            }
        }

        webAuthSession?.presentationContextProvider = self
        webAuthSession?.prefersEphemeralWebBrowserSession = false
        webAuthSession?.start()
    }

    private func exchangeGoogleCodeForTokens(code: String, verifier: String, backendUrl: URL) async {
        isAuthenticating = true

        do {
            var request = URLRequest(url: backendUrl.appendingPathComponent("/auth/google/callback"))
            request.httpMethod = "POST"
            request.setValue("application/json", forHTTPHeaderField: "Content-Type")

            let payload: [String: String] = [
                "code": code,
                "code_verifier": verifier,
                "client_id": oauthConfig.googleClientId ?? ""
            ]
            request.httpBody = try JSONSerialization.data(withJSONObject: payload)

            let (data, response) = try await URLSession.shared.data(for: request)
            guard let httpResponse = response as? HTTPURLResponse, (200...299).contains(httpResponse.statusCode) else {
                let errText = String(data: data, encoding: .utf8) ?? "Backend token exchange failed"
                throw SSEError.serverError(statusCode: (response as? HTTPURLResponse)?.statusCode ?? 400, message: errText)
            }

            let tokenResp = try JSONDecoder().decode(TokenResponse.self, from: data)
            _ = await signInWithToken(tokenResp.accessToken)
        } catch {
            isAuthenticating = false
            self.authError = "Google token exchange failed: \(error.localizedDescription)"
        }
    }

    // MARK: - Sign Out

    public func signOut() async {
        await KeychainManager.shared.clearAll()
        UserDefaults.standard.removeObject(forKey: "openai_user_email")
        UserDefaults.standard.removeObject(forKey: "openai_user_name")
        UserDefaults.standard.removeObject(forKey: "openai_cached_plan")

        currentUser = nil
        activeAccount = nil
        authError = nil
        authState = .unauthenticated
    }

    // MARK: - ASWebAuthenticationPresentationContextProviding

    public func presentationAnchor(for session: ASWebAuthenticationSession) -> ASPresentationAnchor {
        guard let windowScene = UIApplication.shared.connectedScenes.first as? UIWindowScene,
              let window = windowScene.windows.first(where: { $0.isKeyWindow }) else {
            return ASPresentationAnchor()
        }
        return window
    }

    // MARK: - PKCE & Cryptographic Utilities (RFC 7636)

    private func generateCodeVerifier() -> String {
        var buffer = [UInt8](repeating: 0, count: 32)
        _ = SecRandomCopyBytes(kSecRandomDefault, buffer.count, &buffer)
        return Data(buffer).base64URLEncodedString()
    }

    private func generateCodeChallenge(from verifier: String) -> String {
        guard let data = verifier.data(using: .utf8) else { return "" }
        let hash = SHA256.hash(data: data)
        return Data(hash).base64URLEncodedString()
    }

    private func generateRandomState() -> String {
        var buffer = [UInt8](repeating: 0, count: 24)
        _ = SecRandomCopyBytes(kSecRandomDefault, buffer.count, &buffer)
        return Data(buffer).base64URLEncodedString()
    }

    private func decodeEmailFromJWT(_ jwt: String) -> String? {
        let parts = jwt.split(separator: ".")
        guard parts.count >= 2 else { return nil }
        var base64 = String(parts[1])
            .replacingOccurrences(of: "-", with: "+")
            .replacingOccurrences(of: "_", with: "/")
        while base64.count % 4 != 0 {
            base64.append("=")
        }
        guard let payloadData = Data(base64Encoded: base64),
              let json = try? JSONSerialization.jsonObject(with: payloadData) as? [String: Any] else {
            return nil
        }
        return json["email"] as? String ?? json["https://api.openai.com/profile"] as? String
    }
}

// MARK: - Data URL-Safe Base64 Extension

extension Data {
    public func base64URLEncodedString() -> String {
        return self.base64EncodedString()
            .replacingOccurrences(of: "+", with: "-")
            .replacingOccurrences(of: "/", with: "_")
            .replacingOccurrences(of: "=", with: "")
    }
}
