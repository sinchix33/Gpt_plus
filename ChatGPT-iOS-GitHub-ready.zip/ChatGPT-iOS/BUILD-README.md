# ChatGPT-iOS build package

This repository is configured to generate an **unsigned iOS IPA** using GitHub Actions.
The IPA is packaged as `Payload/ChatGPT.app` and is intended for later signing by the
device owner's signing tool. GitHub Actions does not sign this build.

## Build
1. Push the contents of this folder to the `main` or `master` branch.
2. Open GitHub -> Actions -> Build unsigned iOS IPA.
3. Select **Run workflow** (or let a push trigger it).
4. Download the `ChatGPT-unsigned-IPA` artifact after the workflow succeeds.

## Important
- The bundle identifier is `com.sinchi.chatgpt.ios` to avoid claiming Apple's/OpenAI's
  official `com.openai.chatgpt` app identity and to avoid colliding with the official app.
- This project is an independent, incomplete port scaffold. A successful compile/package
  does not prove that authentication, backend compatibility, subscriptions, voice, or
  feature parity work. Those require runtime testing and valid supported service access.
- No signing certificate, provisioning profile, or signing secret is used in this workflow.
