import SwiftUI
import SwiftData

// MARK: - Main iOS Application Entry Point

@main
struct ChatGPTApp: App {
    @State private var authManager = AuthenticationManager.shared
    @State private var chatViewModel = ChatViewModel()
    @State private var conversationListViewModel = ConversationListViewModel()
    @State private var isSidebarOpen: Bool = false
    @State private var showSettings: Bool = false
    @State private var showLoginView: Bool = false
    @State private var isGuestMode: Bool = false

    var sharedModelContainer: ModelContainer = {
        let schema = Schema([
            DBConversationEntity.self,
            DBMessageEntity.self,
            DBMessageChunkEntity.self,
            DBWebSocketTopicOffsetEntity.self,
            DBCalpicoRoomCacheEntity.self,
            DBCalpicoUserCacheEntity.self
        ])
        let modelConfiguration = ModelConfiguration(schema: schema, isStoredInMemoryOnly: false)

        do {
            return try ModelContainer(for: schema, configurations: [modelConfiguration])
        } catch {
            fatalError("Could not initialize SwiftData ModelContainer: \(error)")
        }
    }()

    init() {
        BackgroundTaskManager.shared.registerBackgroundTasks()
    }

    var body: some Scene {
        WindowGroup {
            Group {
                if authManager.authState == .loading {
                    ZStack {
                        Color(uiColor: .systemBackground).ignoresSafeArea()
                        VStack(spacing: 16) {
                            Image(systemName: "sparkles")
                                .font(.system(size: 48, weight: .semibold))
                                .foregroundStyle(Color.accentColor)
                            ProgressView()
                                .tint(Color.accentColor)
                        }
                    }
                } else if !authManager.isAuthenticated && !isGuestMode {
                    LoginView(authManager: authManager) {
                        withAnimation {
                            isGuestMode = true
                        }
                    }
                } else {
                    mainAppInterface
                }
            }
            .task {
                await authManager.restoreSession()
            }
            .sheet(isPresented: $showSettings) {
                SettingsView()
            }
            .sheet(isPresented: $showLoginView) {
                LoginView(authManager: authManager) {
                    showLoginView = false
                }
            }
            .onOpenURL { url in
                handleDeepLink(url)
            }
            .modelContainer(sharedModelContainer)
        }
    }

    private var mainAppInterface: some View {
        ZStack {
            // Primary Chat View
            ChatView(viewModel: chatViewModel) {
                withAnimation(.spring(response: 0.35, dampingFraction: 0.85)) {
                    isSidebarOpen = true
                }
            }
            .disabled(isSidebarOpen)

            // Sidebar Drawer Overlay
            if isSidebarOpen {
                Color.black.opacity(0.4)
                    .ignoresSafeArea()
                    .onTapGesture {
                        withAnimation(.spring(response: 0.35, dampingFraction: 0.85)) {
                            isSidebarOpen = false
                        }
                    }

                HStack(spacing: 0) {
                    SidebarView(
                        listViewModel: conversationListViewModel,
                        onSelectConversation: { convId in
                            withAnimation {
                                isSidebarOpen = false
                            }
                            chatViewModel.clearChat()
                            chatViewModel.currentConversationId = convId
                        },
                        onNewChat: {
                            withAnimation {
                                isSidebarOpen = false
                            }
                            chatViewModel.clearChat()
                        },
                        onOpenSettings: {
                            showSettings = true
                        },
                        onOpenLogin: {
                            showLoginView = true
                        }
                    )
                    .frame(width: min(UIScreen.main.bounds.width * 0.82, 320))
                    .background(Color(uiColor: .systemBackground))
                    .transition(.move(edge: .leading))

                    Spacer()
                }
            }
        }
    }

    private func handleDeepLink(_ url: URL) {
        // Handle universal link routing (matching ChatGptDeeplinkActivity)
        guard let components = URLComponents(url: url, resolvingAgainstBaseURL: true) else { return }

        if components.path.hasPrefix("/c/") {
            let convId = String(components.path.dropFirst(3))
            chatViewModel.clearChat()
            chatViewModel.currentConversationId = convId
        } else if components.path == "/subscription" || components.path == "/up/" {
            showSettings = true
        }
    }
}
