import Foundation

// MARK: - OpenAI Network Client Actor

public actor OpenAINetworkClient {
    public static let shared = OpenAINetworkClient()

    private let session: URLSession
    private let baseUrl: URL
    private let authBaseUrl: URL
    private let sseReader: SSEStreamReader
    private let decoder: JSONDecoder

    public init(
        baseUrl: URL = URL(string: "https://android.chat.openai.com")!,
        authBaseUrl: URL = URL(string: "https://auth.openai.com")!,
        session: URLSession = .shared
    ) {
        self.baseUrl = baseUrl
        self.authBaseUrl = authBaseUrl
        self.session = session
        self.sseReader = SSEStreamReader()
        self.decoder = JSONDecoder()
    }

    public func execute<T: Decodable>(_ endpoint: OpenAIEndpoint) async throws -> T {
        let token = await KeychainManager.shared.get(key: .accessToken)
        let request = try endpoint.buildRequest(baseUrl: baseUrl, token: token)

        let (data, response) = try await session.data(for: request)

        guard let httpResponse = response as? HTTPURLResponse else {
            throw URLError(.badServerResponse)
        }

        if httpResponse.statusCode == 401 {
            // Attempt token refresh
            let refreshed = try await refreshTokenIfNeeded()
            if refreshed {
                let retryToken = await KeychainManager.shared.get(key: .accessToken)
                let retryRequest = try endpoint.buildRequest(baseUrl: baseUrl, token: retryToken)
                let (retryData, _) = try await session.data(for: retryRequest)
                return try decoder.decode(T.self, from: retryData)
            } else {
                throw SSEError.serverError(statusCode: 401, message: "Unauthorized session")
            }
        }

        guard (200...299).contains(httpResponse.statusCode) else {
            let errorMsg = String(data: data, encoding: .utf8) ?? "Unknown server error"
            throw SSEError.serverError(statusCode: httpResponse.statusCode, message: errorMsg)
        }

        return try decoder.decode(T.self, from: data)
    }

    public func executeStream(_ endpoint: OpenAIEndpoint) async throws -> AsyncThrowingStream<ConversationStreamChunk, Error> {
        let token = await KeychainManager.shared.get(key: .accessToken)

        if let token = token, token.hasPrefix("sk-") {
            // OpenAI Developer API Key Mode (Standard OpenAI Platform Chat Completions)
            if case .conversationStream(let convRequest) = endpoint {
                let apiModel = convRequest.model.contains("4o") ? "gpt-4o" : (convRequest.model.contains("o1") ? "o1-mini" : "gpt-4o-mini")
                var chatMessages: [[String: String]] = []
                for msg in convRequest.messages {
                    let role = msg.author.role == .user ? "user" : "assistant"
                    chatMessages.append(["role": role, "content": msg.content.joinedText])
                }
                let payload: [String: Any] = [
                    "model": apiModel,
                    "messages": chatMessages,
                    "stream": true
                ]
                var request = URLRequest(url: URL(string: "https://api.openai.com/v1/chat/completions")!)
                request.httpMethod = "POST"
                request.setValue("application/json", forHTTPHeaderField: "Content-Type")
                request.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
                request.httpBody = try JSONSerialization.data(withJSONObject: payload)

                let (asyncBytes, response) = try await session.bytes(for: request)
                return sseReader.parseStream(bytes: asyncBytes, response: response)
            }
        }

        let request = try endpoint.buildRequest(baseUrl: baseUrl, token: token)
        let (asyncBytes, response) = try await session.bytes(for: request)
        return sseReader.parseStream(bytes: asyncBytes, response: response)
    }

    // MARK: - Direct OpenAI Platform API Key Validation

    public func validateApiKey(_ key: String) async throws -> Bool {
        let cleanKey = key.trimmingCharacters(in: .whitespacesAndNewlines)
        guard cleanKey.hasPrefix("sk-") else {
            throw SSEError.serverError(statusCode: 400, message: "Invalid API key format. OpenAI API keys must begin with 'sk-'.")
        }

        let url = URL(string: "https://api.openai.com/v1/models")!
        var request = URLRequest(url: url)
        request.httpMethod = "GET"
        request.setValue("Bearer \(cleanKey)", forHTTPHeaderField: "Authorization")
        request.setValue("application/json", forHTTPHeaderField: "Accept")

        let (data, response) = try await session.data(for: request)
        guard let httpResponse = response as? HTTPURLResponse else {
            throw URLError(.badServerResponse)
        }

        if httpResponse.statusCode == 200 {
            return true
        } else if httpResponse.statusCode == 401 {
            throw SSEError.serverError(statusCode: 401, message: "Invalid OpenAI API Key. Please verify the key at platform.openai.com.")
        } else if httpResponse.statusCode == 429 {
            throw SSEError.serverError(statusCode: 429, message: "OpenAI API rate limit or quota exceeded. Please check your account billing.")
        } else {
            let msg = String(data: data, encoding: .utf8) ?? "HTTP \(httpResponse.statusCode)"
            throw SSEError.serverError(statusCode: httpResponse.statusCode, message: msg)
        }
    }

    public func refreshTokenIfNeeded() async throws -> Bool {
        guard let refreshToken = await KeychainManager.shared.get(key: .refreshToken) else {
            return false
        }

        guard let url = URL(string: "/oauth/token", relativeTo: authBaseUrl) else {
            return false
        }

        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")

        let tokenReq = TokenRequest.refreshToken(
            refreshToken: refreshToken,
            clientId: "pvd_chatgpt_mobile_client",
            redirectUri: "com.openai.chatgpt://auth0.openai.com/ios/com.openai.chatgpt/callback"
        )
        request.httpBody = try JSONEncoder().encode(tokenReq)

        let (data, response) = try await session.data(for: request)
        guard let httpResponse = response as? HTTPURLResponse, (200...299).contains(httpResponse.statusCode) else {
            return false
        }

        let tokenResponse = try decoder.decode(TokenResponse.self, from: data)
        try await KeychainManager.shared.save(key: .accessToken, string: tokenResponse.accessToken)
        if let newRefresh = tokenResponse.refreshToken {
            try await KeychainManager.shared.save(key: .refreshToken, string: newRefresh)
        }
        return true
    }
}
