import Foundation
import SwiftUI
import Combine
import UIKit

// MARK: - Chat ViewModel with Full Multimodal & Attachment Integration

@MainActor
@Observable
public final class ChatViewModel {
    // MARK: - State Properties
    public var currentConversationId: String?
    public var messages: [MessagePayload] = []
    public var activeModel: ModelSpec
    public var inputText: String = ""
    public var isGenerating: Bool = false
    public var errorMessage: String?
    public var showErrorAlert: Bool = false

    // Staged Attachments
    public var stagedAttachments: [AttachmentItem] = []
    public var showAttachmentMenu: Bool = false
    public var showPhotoPicker: Bool = false
    public var showCameraCapture: Bool = false
    public var showDocumentPicker: Bool = false

    private let networkClient: OpenAINetworkClient
    private var streamingTask: Task<Void, Never>?

    public init(
        conversationId: String? = nil,
        networkClient: OpenAINetworkClient = .shared,
        initialModel: ModelSpec = ModelSpec.availableModels[0]
    ) {
        self.currentConversationId = conversationId
        self.networkClient = networkClient
        self.activeModel = initialModel
    }

    // MARK: - Attachment Management

    public func addAttachment(_ item: AttachmentItem) {
        stagedAttachments.append(item)
    }

    public func removeAttachment(_ item: AttachmentItem) {
        stagedAttachments.removeAll { $0.id == item.id }
    }

    public func clearAttachments() {
        stagedAttachments.removeAll()
    }

    // MARK: - Message Actions

    public func sendMessage() {
        let trimmed = inputText.trimmingCharacters(in: .whitespacesAndNewlines)
        guard (!trimmed.isEmpty || !stagedAttachments.isEmpty), !isGenerating else { return }

        let userMsgId = UUID().uuidString
        let parentId = messages.last?.id ?? "client-root"

        // Build Content Parts (Text + Multimodal Attachments)
        var contentParts: [ContentPart] = []
        let attachmentsToSend = self.stagedAttachments

        // 1. Process Images into Multimodal Parts
        for attachment in attachmentsToSend {
            if case .image(let uiImage) = attachment.type {
                if let jpegData = uiImage.jpegData(compressionQuality: 0.75) {
                    let base64String = jpegData.base64EncodedString()
                    let dataUri = "data:image/jpeg;base64,\(base64String)"
                    contentParts.append(
                        ContentPart(
                            assetPointer: dataUri,
                            mimeType: "image/jpeg",
                            width: Int(uiImage.size.width),
                            height: Int(uiImage.size.height)
                        )
                    )
                }
            }
        }

        // 2. Process Documents / Text into Content
        var combinedText = trimmed
        for attachment in attachmentsToSend {
            if case .document(_, let filename, _, _, let textContent) = attachment.type {
                if let text = textContent, !text.isEmpty {
                    combinedText += "\n\n[Attached File: \(filename)]\n```\n\(text)\n```"
                } else {
                    combinedText += "\n\n[Attached File: \(filename) (\(attachment.sizeString))]"
                }
            }
        }

        if !combinedText.isEmpty {
            contentParts.append(ContentPart(text: combinedText))
        }

        let contentType: ContentType = contentParts.contains(where: { $0.assetPointer != nil }) ? .multimodalText : .text
        let userContent = MessageContent(contentType: contentType, parts: contentParts)

        let userMessage = MessagePayload(
            id: userMsgId,
            author: Author(role: .user),
            content: userContent,
            status: .finishedSuccessfully,
            metadata: MessageMetadata(parentId: parentId)
        )

        messages.append(userMessage)
        inputText = ""
        clearAttachments()
        isGenerating = true
        errorMessage = nil

        // Prepare placeholder assistant message
        let assistantMsgId = UUID().uuidString
        let placeholderAssistantMessage = MessagePayload(
            id: assistantMsgId,
            author: Author(role: .assistant, name: activeModel.title),
            content: MessageContent(text: ""),
            status: .inProgress,
            metadata: MessageMetadata(modelSlug: activeModel.slug, parentId: userMsgId)
        )
        messages.append(placeholderAssistantMessage)

        let request = ConversationRequest(
            action: "next",
            messages: [userMessage],
            parentMessageId: parentId,
            model: activeModel.slug,
            conversationId: currentConversationId,
            historyAndTrainingDisabled: !AppSettings.shared.isHistoryAndTrainingEnabled
        )

        streamingTask?.cancel()
        streamingTask = Task {
            do {
                let stream = try await networkClient.executeStream(.conversationStream(request: request))

                for try await chunk in stream {
                    if Task.isCancelled { break }

                    if let newConvId = chunk.conversationId, currentConversationId == nil {
                        currentConversationId = newConvId
                    }

                    if let incomingMessage = chunk.message {
                        if let index = messages.firstIndex(where: { $0.id == assistantMsgId || $0.id == incomingMessage.id }) {
                            messages[index] = incomingMessage
                        }
                    }
                }

                // Finalize assistant message status
                if let lastIdx = messages.indices.last, messages[lastIdx].author.role == .assistant {
                    let finalMessage = messages[lastIdx]
                    messages[lastIdx] = MessagePayload(
                        id: finalMessage.id,
                        author: finalMessage.author,
                        createTime: finalMessage.createTime,
                        content: finalMessage.content,
                        status: .finishedSuccessfully,
                        metadata: finalMessage.metadata
                    )
                }

                isGenerating = false
            } catch {
                if !Task.isCancelled {
                    isGenerating = false
                    errorMessage = error.localizedDescription
                    showErrorAlert = true

                    // Mark assistant message as failed if empty
                    if let lastIdx = messages.indices.last, messages[lastIdx].author.role == .assistant {
                        if messages[lastIdx].content.joinedText.isEmpty {
                            messages.remove(at: lastIdx)
                        }
                    }
                }
            }
        }
    }

    public func stopGeneration() {
        streamingTask?.cancel()
        streamingTask = nil
        isGenerating = false
    }

    public func selectModel(_ model: ModelSpec) {
        self.activeModel = model
        AppSettings.shared.selectedModelSlug = model.slug
    }

    public func clearChat() {
        stopGeneration()
        currentConversationId = nil
        messages.removeAll()
        inputText = ""
        clearAttachments()
        errorMessage = nil
    }
}
