import Foundation
import UIKit
import UniformTypeIdentifiers

// MARK: - Attachment Types & Staged Items

public enum AttachmentType: Equatable {
    case image(UIImage)
    case document(data: Data, filename: String, sizeBytes: Int64, mimeType: String, textContent: String?)

    public static func == (lhs: AttachmentType, rhs: AttachmentType) -> Bool {
        switch (lhs, rhs) {
        case (.image(let img1), .image(let img2)):
            return img1 === img2 || img1.pngData() == img2.pngData()
        case (.document(_, let f1, let s1, _, _), .document(_, let f2, let s2, _, _)):
            return f1 == f2 && s1 == s2
        default:
            return false
        }
    }
}

public struct AttachmentItem: Identifiable, Equatable {
    public let id: String
    public let type: AttachmentType
    public let filename: String
    public let sizeString: String
    public let thumbnail: UIImage?

    public init(
        id: String = UUID().uuidString,
        type: AttachmentType,
        filename: String,
        sizeString: String,
        thumbnail: UIImage? = nil
    ) {
        self.id = id
        self.type = type
        self.filename = filename
        self.sizeString = sizeString
        self.thumbnail = thumbnail
    }

    public static func fromImage(_ image: UIImage, filename: String = "photo.jpg") -> AttachmentItem {
        let size = Int64(image.jpegData(compressionQuality: 0.8)?.count ?? 0)
        return AttachmentItem(
            type: .image(image),
            filename: filename,
            sizeString: ByteCountFormatter.string(fromByteCount: size, countStyle: .file),
            thumbnail: image
        )
    }

    public static func fromDocument(url: URL) -> AttachmentItem? {
        guard url.startAccessingSecurityScopedResource() else { return nil }
        defer { url.stopAccessingSecurityScopedResource() }

        do {
            let data = try Data(contentsOf: url)
            let filename = url.lastPathComponent
            let size = Int64(data.count)
            let ext = url.pathExtension.lowercased()

            let mimeType: String = {
                if let utType = UTType(filenameExtension: ext), let mime = utType.preferredMIMEType {
                    return mime
                }
                return "application/octet-stream"
            }()

            var textContent: String? = nil
            let textExtensions = ["txt", "md", "json", "csv", "swift", "py", "js", "ts", "html", "css", "xml", "yaml", "yml", "sh"]
            if textExtensions.contains(ext) {
                textContent = String(data: data, encoding: .utf8)
            }

            return AttachmentItem(
                type: .document(data: data, filename: filename, sizeBytes: size, mimeType: mimeType, textContent: textContent),
                filename: filename,
                sizeString: ByteCountFormatter.string(fromByteCount: size, countStyle: .file),
                thumbnail: nil
            )
        } catch {
            return nil
        }
    }
}
