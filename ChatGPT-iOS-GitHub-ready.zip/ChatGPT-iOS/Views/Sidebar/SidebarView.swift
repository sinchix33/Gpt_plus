import SwiftUI

// MARK: - Navigation Sidebar Drawer

public struct SidebarView: View {
    @Bindable public var listViewModel: ConversationListViewModel
    @State private var authManager = AuthenticationManager.shared
    public let onSelectConversation: (String) -> Void
    public let onNewChat: () -> Void
    public let onOpenSettings: () -> Void
    public var onOpenLogin: (() -> Void)?

    public init(
        listViewModel: ConversationListViewModel,
        onSelectConversation: @escaping (String) -> Void,
        onNewChat: @escaping () -> Void,
        onOpenSettings: @escaping () -> Void,
        onOpenLogin: (() -> Void)? = nil
    ) {
        self.listViewModel = listViewModel
        self.onSelectConversation = onSelectConversation
        self.onNewChat = onNewChat
        self.onOpenSettings = onOpenSettings
        self.onOpenLogin = onOpenLogin
    }

    public var body: some View {
        VStack(spacing: 0) {
            // Header Search & New Chat
            VStack(spacing: 12) {
                HStack {
                    HStack(spacing: 8) {
                        Image(systemName: "magnifyingglass")
                            .foregroundStyle(.secondary)
                        TextField("Search", text: $listViewModel.searchQuery)
                    }
                    .padding(.horizontal, 10)
                    .padding(.vertical, 8)
                    .background(Color(uiColor: .tertiarySystemFill))
                    .clipShape(RoundedRectangle(cornerRadius: 10, style: .continuous))

                    Button {
                        onNewChat()
                    } label: {
                        Image(systemName: "square.and.pencil")
                            .font(.headline)
                            .foregroundStyle(.primary)
                            .padding(8)
                    }
                }
            }
            .padding(.horizontal, 16)
            .padding(.top, 16)
            .padding(.bottom, 8)

            // Conversation History List
            List {
                Section {
                    ForEach(listViewModel.filteredConversations) { conv in
                        Button {
                            onSelectConversation(conv.id)
                        } label: {
                            Text(conv.title)
                                .font(.subheadline)
                                .foregroundStyle(.primary)
                                .lineLimit(1)
                        }
                        .swipeActions(edge: .trailing) {
                            Button(role: .destructive) {
                                Task {
                                    await listViewModel.deleteConversation(id: conv.id)
                                }
                            } label: {
                                Label("Delete", systemImage: "trash")
                            }
                        }
                    }
                } header: {
                    Text("Recent Chats")
                }
            }
            .listStyle(.plain)

            Divider()

            // User Profile & Settings Footer
            HStack(spacing: 12) {
                Button {
                    if authManager.isAuthenticated {
                        onOpenSettings()
                    } else {
                        onOpenLogin?()
                    }
                } label: {
                    HStack(spacing: 12) {
                        Image(systemName: authManager.isAuthenticated ? "person.crop.circle.fill" : "person.crop.circle.badge.plus")
                            .font(.title2)
                            .foregroundStyle(authManager.isAuthenticated ? .secondary : Color.accentColor)

                        VStack(alignment: .leading, spacing: 2) {
                            Text(authManager.currentUser?.email ?? authManager.currentUser?.name ?? (authManager.isAuthenticated ? "User Account" : "Sign In"))
                                .font(.subheadline.bold())
                                .foregroundStyle(.primary)
                                .lineLimit(1)
                            Text(authManager.activeAccount?.planType.displayName ?? (authManager.currentUser?.planType.capitalized ?? (authManager.isAuthenticated ? "Free Plan" : "Tap to log in")))
                                .font(.caption)
                                .foregroundStyle(.secondary)
                        }
                    }
                }
                .buttonStyle(.plain)

                Spacer()

                Button {
                    onOpenSettings()
                } label: {
                    Image(systemName: "ellipsis")
                        .font(.headline)
                        .foregroundStyle(.secondary)
                        .padding(8)
                }
            }
            .padding(.horizontal, 16)
            .padding(.vertical, 12)
            .background(Color(uiColor: .secondarySystemBackground))
        }
        .task {
            await listViewModel.loadConversations()
        }
    }
}
