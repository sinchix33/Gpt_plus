import SwiftUI

// MARK: - Staged Attachment Preview Strip (Displayed above input field)

public struct AttachmentPreviewStrip: View {
    public let attachments: [AttachmentItem]
    public let onRemove: (AttachmentItem) -> Void

    public init(attachments: [AttachmentItem], onRemove: @escaping (AttachmentItem) -> Void) {
        self.attachments = attachments
        self.onRemove = onRemove
    }

    public var body: some View {
        if !attachments.isEmpty {
            ScrollView(.horizontal, showsIndicators: false) {
                HStack(spacing: 12) {
                    ForEach(attachments) { item in
                        attachmentCard(item)
                    }
                }
                .padding(.horizontal, 16)
                .padding(.vertical, 8)
            }
            .background(Color(uiColor: .systemBackground))
            .transition(.move(edge: .bottom).combined(with: .opacity))
        }
    }

    @ViewBuilder
    private func attachmentCard(_ item: AttachmentItem) -> some View {
        ZStack(alignment: .topTrailing) {
            switch item.type {
            case .image(let uiImage):
                Image(uiImage: uiImage)
                    .resizable()
                    .scaledToFill()
                    .frame(width: 68, height: 68)
                    .clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))
                    .overlay(
                        RoundedRectangle(cornerRadius: 12, style: .continuous)
                            .stroke(Color.white.opacity(0.15), lineWidth: 1)
                    )

            case .document(_, let filename, _, _, _):
                HStack(spacing: 8) {
                    Image(systemName: iconForFilename(filename))
                        .font(.title3)
                        .foregroundStyle(Color.accentColor)

                    VStack(alignment: .leading, spacing: 2) {
                        Text(filename)
                            .font(.caption.bold())
                            .foregroundStyle(.primary)
                            .lineLimit(1)
                            .frame(maxWidth: 110, alignment: .leading)

                        Text(item.sizeString)
                            .font(.caption2)
                            .foregroundStyle(.secondary)
                    }
                }
                .padding(.horizontal, 10)
                .padding(.vertical, 10)
                .frame(height: 68)
                .background(Color(uiColor: .secondarySystemBackground))
                .clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))
                .overlay(
                    RoundedRectangle(cornerRadius: 12, style: .continuous)
                        .stroke(Color.white.opacity(0.1), lineWidth: 1)
                )
            }

            // Remove Button
            Button {
                withAnimation(.easeInOut(duration: 0.2)) {
                    onRemove(item)
                }
            } label: {
                Image(systemName: "xmark.circle.fill")
                    .font(.system(size: 18))
                    .foregroundStyle(.white, Color.black.opacity(0.7))
                    .padding(4)
            }
            .offset(x: 6, y: -6)
        }
    }

    private func iconForFilename(_ filename: String) -> String {
        let ext = (filename as NSString).pathExtension.lowercased()
        switch ext {
        case "pdf": return "doc.richtext.fill"
        case "txt", "md": return "doc.text.fill"
        case "json", "csv": return "tablecells.fill"
        case "swift", "py", "js", "html": return "chevron.left.forwardslash.chevron.right"
        default: return "doc.fill"
        }
    }
}
