import SwiftUI

// MARK: - Login & Authentication Screen

public struct LoginView: View {
    @Bindable public var authManager: AuthenticationManager
    public let onGuestContinue: () -> Void

    @State private var showTokenSheet: Bool = false
    @State private var showInfoSheet: Bool = false
    @State private var selectedAuthMode: Int = 0 // 0: ChatGPT Session, 1: OpenAI API Key
    @State private var inputToken: String = ""
    @State private var inputEmail: String = ""

    public init(authManager: AuthenticationManager, onGuestContinue: @escaping () -> Void) {
        self.authManager = authManager
        self.onGuestContinue = onGuestContinue
    }

    public var body: some View {
        ZStack {
            Color(uiColor: .systemBackground).ignoresSafeArea()

            VStack(spacing: 24) {
                // Top Info Bar
                HStack {
                    Spacer()
                    Button {
                        showInfoSheet = true
                    } label: {
                        Image(systemName: "questionmark.circle")
                            .font(.title3)
                            .foregroundStyle(.secondary)
                            .padding(8)
                    }
                }
                .padding(.horizontal, 16)
                .padding(.top, 8)

                Spacer()

                // Brand Header
                VStack(spacing: 16) {
                    Image(systemName: "sparkles")
                        .font(.system(size: 52, weight: .semibold))
                        .foregroundStyle(Color.accentColor)

                    Text("Welcome to ChatGPT")
                        .font(.system(size: 28, weight: .bold))
                        .foregroundStyle(.primary)

                    Text("Log in with your ChatGPT account, Google account, or developer API key.")
                        .font(.subheadline)
                        .foregroundStyle(.secondary)
                        .multilineTextAlignment(.center)
                        .padding(.horizontal, 32)
                }

                // Error Banner
                if let err = authManager.authError {
                    VStack(alignment: .leading, spacing: 8) {
                        HStack(alignment: .top, spacing: 10) {
                            Image(systemName: "exclamationmark.triangle.fill")
                                .foregroundStyle(.yellow)
                                .font(.body)

                            Text(err)
                                .font(.footnote)
                                .foregroundStyle(.primary)
                                .fixedSize(horizontal: false, vertical: true)
                        }

                        HStack {
                            Spacer()
                            Button("Dismiss") {
                                authManager.authError = nil
                            }
                            .font(.caption.bold())
                            .foregroundStyle(Color.accentColor)
                        }
                    }
                    .padding(14)
                    .background(Color(uiColor: .secondarySystemBackground))
                    .clipShape(RoundedRectangle(cornerRadius: 14, style: .continuous))
                    .overlay(
                        RoundedRectangle(cornerRadius: 14, style: .continuous)
                            .stroke(Color.yellow.opacity(0.3), lineWidth: 1)
                    )
                    .padding(.horizontal, 24)
                }

                Spacer()

                // Authentication Action Buttons
                VStack(spacing: 12) {
                    // 1. Continue with ChatGPT
                    Button {
                        authManager.startChatGPTAuth()
                    } label: {
                        HStack(spacing: 12) {
                            if authManager.isAuthenticating {
                                ProgressView()
                                    .tint(.white)
                            } else {
                                Image(systemName: "sparkles")
                                    .font(.headline)
                                Text("Continue with ChatGPT")
                                    .font(.headline)
                            }
                        }
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 15)
                        .background(Color.accentColor)
                        .foregroundStyle(.white)
                        .clipShape(RoundedRectangle(cornerRadius: 14, style: .continuous))
                    }
                    .disabled(authManager.isAuthenticating)

                    // 2. Continue with Google
                    Button {
                        authManager.startGoogleAuth()
                    } label: {
                        HStack(spacing: 12) {
                            googleIcon
                                .frame(width: 20, height: 20)
                            Text("Continue with Google")
                                .font(.headline)
                                .foregroundStyle(.primary)
                        }
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 15)
                        .background(Color(uiColor: .secondarySystemBackground))
                        .clipShape(RoundedRectangle(cornerRadius: 14, style: .continuous))
                        .overlay(
                            RoundedRectangle(cornerRadius: 14, style: .continuous)
                                .stroke(Color(uiColor: .separator), lineWidth: 0.8)
                        )
                    }
                    .disabled(authManager.isAuthenticating)

                    // 3. Direct Session Token or API Key
                    Button {
                        showTokenSheet = true
                    } label: {
                        HStack(spacing: 10) {
                            Image(systemName: "key.fill")
                                .font(.subheadline)
                            Text("Sign in with Session Token or API Key")
                                .font(.subheadline.weight(.semibold))
                        }
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 13)
                        .background(Color(uiColor: .tertiarySystemFill))
                        .foregroundStyle(.primary)
                        .clipShape(RoundedRectangle(cornerRadius: 14, style: .continuous))
                    }
                    .disabled(authManager.isAuthenticating)

                    // 4. Continue as Guest
                    Button {
                        onGuestContinue()
                    } label: {
                        Text("Continue as Guest")
                            .font(.subheadline)
                            .foregroundStyle(.secondary)
                            .padding(.top, 4)
                    }
                }
                .padding(.horizontal, 24)
                .padding(.bottom, 24)
            }
        }
        .sheet(isPresented: $showTokenSheet) {
            tokenEntrySheet
        }
        .sheet(isPresented: $showInfoSheet) {
            authInfoSheet
        }
    }

    // MARK: - Google 'G' Logo Representation

    private var googleIcon: some View {
        ZStack {
            Circle()
                .fill(Color.white)
            Text("G")
                .font(.system(size: 14, weight: .bold, design: .rounded))
                .foregroundStyle(Color.red)
        }
    }

    // MARK: - Token Entry Sheet

    private var tokenEntrySheet: some View {
        NavigationStack {
            Form {
                Section {
                    Picker("Method", selection: $selectedAuthMode) {
                        Text("Session Token").tag(0)
                        Text("OpenAI API Key").tag(1)
                    }
                    .pickerStyle(.segmented)
                    .padding(.vertical, 4)
                }

                if selectedAuthMode == 0 {
                    Section {
                        TextField("Account Email (optional)", text: $inputEmail)
                            .textContentType(.emailAddress)
                            .autocapitalization(.none)

                        SecureField("Paste accessToken (JWT)", text: $inputToken)
                            .autocapitalization(.none)
                            .disableAutocorrection(true)
                    } header: {
                        Text("ChatGPT Consumer Session")
                    } footer: {
                        Text("Sign in to https://chatgpt.com on Safari, then visit https://chatgpt.com/api/auth/session to copy your active accessToken. Stored securely in your device's Keychain.")
                    }
                } else {
                    Section {
                        SecureField("Paste Secret Key (sk-... or sk-proj-...)", text: $inputToken)
                            .autocapitalization(.none)
                            .disableAutocorrection(true)
                    } header: {
                        Text("OpenAI Platform API Key")
                    } footer: {
                        Text("Generate an API key from https://platform.openai.com/api-keys. Used for developer API access. Stored securely in your device's Keychain.")
                    }
                }
            }
            .navigationTitle(selectedAuthMode == 0 ? "Session Token" : "API Key")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .topBarLeading) {
                    Button("Cancel") {
                        showTokenSheet = false
                    }
                }
                ToolbarItem(placement: .topBarTrailing) {
                    Button("Sign In") {
                        let token = inputToken
                        let email = inputEmail.isEmpty ? nil : inputEmail
                        let isApiMode = (selectedAuthMode == 1)
                        showTokenSheet = false

                        Task {
                            if isApiMode {
                                _ = await authManager.signInWithApiKey(token)
                            } else {
                                _ = await authManager.signInWithToken(token, email: email)
                            }
                        }
                    }
                    .bold()
                    .disabled(inputToken.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
                }
            }
        }
        .presentationDetents([.medium, .large])
    }

    // MARK: - Authentication Help Sheet

    private var authInfoSheet: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 20) {
                    Text("About ChatGPT & Google Authentication")
                        .font(.title2.bold())
                        .foregroundStyle(.primary)

                    VStack(alignment: .leading, spacing: 8) {
                        Text("1. ChatGPT Account Sign-In (OAuth)")
                            .font(.headline)
                        Text("OpenAI restricts consumer web OAuth (auth.openai.com) strictly to its official first-party App Store applications. Custom builds or third-party clients cannot use web OAuth without an authorized OAuth 2.0 Client ID provisioned directly by OpenAI.")
                            .font(.subheadline)
                            .foregroundStyle(.secondary)
                    }

                    VStack(alignment: .leading, spacing: 8) {
                        Text("2. Google Sign-In")
                            .font(.headline)
                        Text("Google Sign-In on iOS requires a Google Cloud project with an iOS OAuth Client ID matching the application's bundle identifier, plus an authentication backend to exchange Google ID tokens for session tokens.")
                            .font(.subheadline)
                            .foregroundStyle(.secondary)
                    }

                    VStack(alignment: .leading, spacing: 8) {
                        Text("3. Supported Legitimate Access Methods")
                            .font(.headline)
                        Text("• ChatGPT Session Token: Copy your personal accessToken from https://chatgpt.com/api/auth/session to connect your existing ChatGPT Plus or Free subscription.\n\n• OpenAI API Key: Use your developer key (sk-...) from platform.openai.com for direct model access.\n\n• Guest Mode: Browse and interact in guest mode without connecting an account.")
                            .font(.subheadline)
                            .foregroundStyle(.secondary)
                    }
                }
                .padding(20)
            }
            .navigationTitle("Authentication Info")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    Button("Done") {
                        showInfoSheet = false
                    }
                }
            }
        }
        .presentationDetents([.medium, .large])
    }
}
