import SwiftUI

// MARK: - Polished Native-Style Authentication Screen

public struct LoginView: View {
    @Bindable public var authManager: AuthenticationManager
    public let onGuestContinue: () -> Void

    @State private var showApiKeySheet: Bool = false
    @State private var showSessionTokenSheet: Bool = false
    @State private var showGoogleSetupSheet: Bool = false
    @State private var showInfoSheet: Bool = false

    // Input States
    @State private var inputApiKey: String = ""
    @State private var inputSessionToken: String = ""
    @State private var inputEmail: String = ""
    @State private var inputGoogleClientId: String = ""
    @State private var inputBackendUrl: String = ""

    public init(authManager: AuthenticationManager, onGuestContinue: @escaping () -> Void) {
        self.authManager = authManager
        self.onGuestContinue = onGuestContinue
    }

    public var body: some View {
        ZStack {
            Color(uiColor: .systemBackground).ignoresSafeArea()

            VStack(spacing: 0) {
                // Top Navigation Bar
                HStack {
                    Spacer()
                    Button {
                        showInfoSheet = true
                    } label: {
                        Image(systemName: "questionmark.circle")
                            .font(.title3)
                            .foregroundStyle(.secondary)
                            .padding(12)
                    }
                }

                Spacer()

                // Brand Header
                VStack(spacing: 16) {
                    Image(systemName: "sparkles")
                        .font(.system(size: 56, weight: .semibold))
                        .foregroundStyle(Color.accentColor)

                    Text("Welcome to ChatGPT")
                        .font(.system(size: 28, weight: .bold))
                        .foregroundStyle(.primary)

                    Text("Connect with an official OpenAI API key, Google account, or session token.")
                        .font(.subheadline)
                        .foregroundStyle(.secondary)
                        .multilineTextAlignment(.center)
                        .padding(.horizontal, 32)
                }

                // Inline Error Feedback Banner
                if let err = authManager.authError {
                    HStack(alignment: .top, spacing: 10) {
                        Image(systemName: "exclamationmark.triangle.fill")
                            .foregroundStyle(.yellow)
                            .font(.footnote)

                        Text(err)
                            .font(.footnote)
                            .foregroundStyle(.primary)
                            .lineLimit(3)

                        Spacer()

                        Button {
                            authManager.authError = nil
                        } label: {
                            Image(systemName: "xmark")
                                .font(.caption.bold())
                                .foregroundStyle(.secondary)
                        }
                    }
                    .padding(12)
                    .background(Color(uiColor: .secondarySystemBackground))
                    .clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))
                    .padding(.horizontal, 24)
                    .padding(.top, 16)
                }

                Spacer()

                // Authentication Action Buttons
                VStack(spacing: 14) {
                    // 1. Primary: Connect with OpenAI API Key
                    Button {
                        showApiKeySheet = true
                    } label: {
                        HStack(spacing: 12) {
                            if authManager.isAuthenticating {
                                ProgressView()
                                    .tint(.white)
                            } else {
                                Image(systemName: "key.fill")
                                    .font(.headline)
                                Text("Connect with OpenAI API Key")
                                    .font(.headline)
                            }
                        }
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 16)
                        .background(Color.accentColor)
                        .foregroundStyle(.white)
                        .clipShape(RoundedRectangle(cornerRadius: 16, style: .continuous))
                    }
                    .disabled(authManager.isAuthenticating)

                    // 2. Secondary: Continue with Google
                    Button {
                        handleGoogleTapped()
                    } label: {
                        HStack(spacing: 12) {
                            googleIconView
                                .frame(width: 22, height: 22)

                            Text("Continue with Google")
                                .font(.headline)
                                .foregroundStyle(.primary)
                        }
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 15)
                        .background(Color(uiColor: .secondarySystemBackground))
                        .clipShape(RoundedRectangle(cornerRadius: 16, style: .continuous))
                        .overlay(
                            RoundedRectangle(cornerRadius: 16, style: .continuous)
                                .stroke(Color(uiColor: .separator), lineWidth: 0.8)
                        )
                    }
                    .disabled(authManager.isAuthenticating)

                    // 3. Tertiary: Connect with ChatGPT Session Token
                    Button {
                        showSessionTokenSheet = true
                    } label: {
                        HStack(spacing: 10) {
                            Image(systemName: "person.badge.key")
                                .font(.subheadline)
                            Text("Connect with ChatGPT Session Token")
                                .font(.subheadline.weight(.semibold))
                        }
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 14)
                        .background(Color(uiColor: .tertiarySystemFill))
                        .foregroundStyle(.primary)
                        .clipShape(RoundedRectangle(cornerRadius: 16, style: .continuous))
                    }
                    .disabled(authManager.isAuthenticating)

                    // 4. Guest Mode
                    Button {
                        onGuestContinue()
                    } label: {
                        Text("Explore as Guest")
                            .font(.subheadline)
                            .foregroundStyle(.secondary)
                            .padding(.top, 4)
                    }
                }
                .padding(.horizontal, 24)
                .padding(.bottom, 24)
            }
        }
        .sheet(isPresented: $showApiKeySheet) {
            apiKeySheetView
        }
        .sheet(isPresented: $showSessionTokenSheet) {
            sessionTokenSheetView
        }
        .sheet(isPresented: $showGoogleSetupSheet) {
            googleSetupSheetView
        }
        .sheet(isPresented: $showInfoSheet) {
            infoSheetView
        }
    }

    private func handleGoogleTapped() {
        if let clientId = authManager.oauthConfig.googleClientId, !clientId.isEmpty {
            authManager.startGoogleAuth()
        } else {
            showGoogleSetupSheet = true
        }
    }

    // MARK: - Google 'G' Icon

    private var googleIconView: some View {
        ZStack {
            Circle()
                .fill(Color.white)
            Text("G")
                .font(.system(size: 14, weight: .bold, design: .rounded))
                .foregroundStyle(Color.red)
        }
    }

    // MARK: - OpenAI API Key Sheet

    private var apiKeySheetView: some View {
        NavigationStack {
            Form {
                Section {
                    SecureField("sk-...", text: $inputApiKey)
                        .autocapitalization(.none)
                        .disableAutocorrection(true)
                } header: {
                    Text("Secret API Key")
                } footer: {
                    Text("Enter your OpenAI Platform API key. Keys start with 'sk-'. Stored securely in your device's Keychain and validated in real time against api.openai.com.")
                }

                Section {
                    Link(destination: URL(string: "https://platform.openai.com/api-keys")!) {
                        HStack {
                            Text("Get API Key from platform.openai.com")
                            Spacer()
                            Image(systemName: "arrow.up.right.square")
                                .font(.footnote)
                        }
                    }
                }
            }
            .navigationTitle("OpenAI API Key")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .topBarLeading) {
                    Button("Cancel") {
                        showApiKeySheet = false
                    }
                }
                ToolbarItem(placement: .topBarTrailing) {
                    Button("Connect") {
                        let key = inputApiKey
                        showApiKeySheet = false
                        Task {
                            _ = await authManager.signInWithApiKey(key)
                        }
                    }
                    .bold()
                    .disabled(!inputApiKey.trimmingCharacters(in: .whitespacesAndNewlines).hasPrefix("sk-"))
                }
            }
        }
        .presentationDetents([.medium, .large])
    }

    // MARK: - ChatGPT Session Token Sheet

    private var sessionTokenSheetView: some View {
        NavigationStack {
            Form {
                Section {
                    TextField("Account Email (optional)", text: $inputEmail)
                        .textContentType(.emailAddress)
                        .autocapitalization(.none)

                    SecureField("Paste accessToken (JWT)", text: $inputSessionToken)
                        .autocapitalization(.none)
                        .disableAutocorrection(true)
                } header: {
                    Text("Active Session Token")
                } footer: {
                    Text("Log in to https://chatgpt.com on Safari, then visit https://chatgpt.com/api/auth/session to copy your active accessToken. Stored securely in Keychain.")
                }
            }
            .navigationTitle("Session Token")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .topBarLeading) {
                    Button("Cancel") {
                        showSessionTokenSheet = false
                    }
                }
                ToolbarItem(placement: .topBarTrailing) {
                    Button("Connect") {
                        let token = inputSessionToken
                        let email = inputEmail.isEmpty ? nil : inputEmail
                        showSessionTokenSheet = false
                        Task {
                            _ = await authManager.signInWithToken(token, email: email)
                        }
                    }
                    .bold()
                    .disabled(inputSessionToken.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
                }
            }
        }
        .presentationDetents([.medium, .large])
    }

    // MARK: - Google Sign-In Setup Sheet

    private var googleSetupSheetView: some View {
        NavigationStack {
            Form {
                Section {
                    TextField("Google Client ID", text: $inputGoogleClientId)
                        .autocapitalization(.none)
                        .disableAutocorrection(true)

                    TextField("Token Backend URL (optional)", text: $inputBackendUrl)
                        .autocapitalization(.none)
                        .disableAutocorrection(true)
                } header: {
                    Text("Google Cloud Credentials")
                } footer: {
                    Text("To use Google Sign-In, provide an iOS OAuth Client ID created in Google Cloud Console matching bundle ID 'com.openai.chatgpt'.")
                }

                Section {
                    Button("Start Google Sign-In") {
                        let clientId = inputGoogleClientId.trimmingCharacters(in: .whitespacesAndNewlines)
                        let backend = URL(string: inputBackendUrl.trimmingCharacters(in: .whitespacesAndNewlines))
                        showGoogleSetupSheet = false
                        authManager.startGoogleAuth(customClientId: clientId.isEmpty ? nil : clientId, customBackendUrl: backend)
                    }
                    .bold()
                    .disabled(inputGoogleClientId.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
                }
            }
            .navigationTitle("Google Sign-In Setup")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .topBarLeading) {
                    Button("Close") {
                        showGoogleSetupSheet = false
                    }
                }
            }
        }
        .presentationDetents([.medium, .large])
    }

    // MARK: - Information Sheet

    private var infoSheetView: some View {
        NavigationStack {
            List {
                Section {
                    VStack(alignment: .leading, spacing: 8) {
                        Text("1. OpenAI API Key (Supported & Recommended)")
                            .font(.headline)
                        Text("The official, documented mechanism for custom and developer iOS applications to communicate with OpenAI. Uses secret keys (sk-...) created at platform.openai.com.")
                            .font(.footnote)
                            .foregroundStyle(.secondary)
                    }
                    .padding(.vertical, 4)

                    VStack(alignment: .leading, spacing: 8) {
                        Text("2. ChatGPT Consumer Web OAuth")
                            .font(.headline)
                        Text("OpenAI restricts consumer web OAuth on auth.openai.com strictly to its first-party App Store applications. Public third-party OAuth client registration is not provided for consumer ChatGPT accounts.")
                            .font(.footnote)
                            .foregroundStyle(.secondary)
                    }
                    .padding(.vertical, 4)

                    VStack(alignment: .leading, spacing: 8) {
                        Text("3. Google Sign-In")
                            .font(.headline)
                        Text("Google Sign-In on iOS requires a registered iOS Client ID from Google Cloud Console matching the application's bundle identifier, plus an authentication backend to exchange identity tokens.")
                            .font(.footnote)
                            .foregroundStyle(.secondary)
                    }
                    .padding(.vertical, 4)
                } header: {
                    Text("Authentication Architecture")
                }
            }
            .navigationTitle("About Authentication")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    Button("Done") {
                        showInfoSheet = false
                    }
                }
            }
        }
        .presentationDetents([.medium, .large])
    }
}
