import SwiftUI

// MARK: - Login & Authentication Screen

public struct LoginView: View {
    @Bindable public var authManager: AuthenticationManager
    public let onGuestContinue: () -> Void

    @State private var showTokenSheet: Bool = false
    @State private var inputToken: String = ""
    @State private var inputEmail: String = ""

    public init(authManager: AuthenticationManager, onGuestContinue: @escaping () -> Void) {
        self.authManager = authManager
        self.onGuestContinue = onGuestContinue
    }

    public var body: some View {
        ZStack {
            Color(uiColor: .systemBackground).ignoresSafeArea()

            VStack(spacing: 32) {
                Spacer()

                // Brand Header
                VStack(spacing: 16) {
                    Image(systemName: "sparkles")
                        .font(.system(size: 54, weight: .semibold))
                        .foregroundStyle(Color.accentColor)

                    Text("Welcome to ChatGPT")
                        .font(.system(size: 28, weight: .bold))
                        .foregroundStyle(.primary)

                    Text("Log in with your ChatGPT account or session token to access your conversations and GPT-4o.")
                        .font(.subheadline)
                        .foregroundStyle(.secondary)
                        .multilineTextAlignment(.center)
                        .padding(.horizontal, 32)
                }

                // Error Banner
                if let err = authManager.authError {
                    HStack(spacing: 10) {
                        Image(systemName: "exclamationmark.triangle.fill")
                            .foregroundStyle(.yellow)
                        Text(err)
                            .font(.caption)
                            .foregroundStyle(.primary)
                            .lineLimit(3)
                    }
                    .padding(.horizontal, 16)
                    .padding(.vertical, 10)
                    .background(Color.yellow.opacity(0.15))
                    .clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))
                    .padding(.horizontal, 24)
                }

                Spacer()

                // Actions
                VStack(spacing: 14) {
                    // Primary Web OAuth Login
                    Button {
                        authManager.startWebAuth()
                    } label: {
                        HStack(spacing: 12) {
                            if authManager.isAuthenticating {
                                ProgressView()
                                    .tint(.white)
                            } else {
                                Image(systemName: "person.badge.key.fill")
                                    .font(.headline)
                                Text("Sign In with ChatGPT Account")
                                    .font(.headline)
                            }
                        }
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 16)
                        .background(Color.accentColor)
                        .foregroundStyle(.white)
                        .clipShape(RoundedRectangle(cornerRadius: 16, style: .continuous))
                    }
                    .disabled(authManager.isAuthenticating)

                    // Secondary: Session Token Login
                    Button {
                        showTokenSheet = true
                    } label: {
                        HStack(spacing: 10) {
                            Image(systemName: "key.fill")
                                .font(.subheadline)
                            Text("Sign In with Session / Access Token")
                                .font(.subheadline.weight(.semibold))
                        }
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 14)
                        .background(Color(uiColor: .secondarySystemBackground))
                        .foregroundStyle(.primary)
                        .clipShape(RoundedRectangle(cornerRadius: 16, style: .continuous))
                    }
                    .disabled(authManager.isAuthenticating)

                    // Guest Option
                    Button {
                        onGuestContinue()
                    } label: {
                        Text("Continue as Guest")
                            .font(.subheadline)
                            .foregroundStyle(.secondary)
                            .padding(.top, 6)
                    }
                }
                .padding(.horizontal, 24)
                .padding(.bottom, 24)
            }
        }
        .sheet(isPresented: $showTokenSheet) {
            tokenEntrySheet
        }
    }

    // MARK: - Token Entry Sheet

    private var tokenEntrySheet: some View {
        NavigationStack {
            Form {
                Section {
                    TextField("Email (optional)", text: $inputEmail)
                        .textContentType(.emailAddress)
                        .autocapitalization(.none)

                    SecureField("Paste Access Token or Session Key", text: $inputToken)
                        .autocapitalization(.none)
                        .disableAutocorrection(true)
                } header: {
                    Text("Session Token")
                } footer: {
                    Text("You can find your accessToken from https://chatgpt.com/api/auth/session or developer settings. Sensitive credentials are encrypted and stored in your device's Keychain.")
                }
            }
            .navigationTitle("Enter Token")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .topBarLeading) {
                    Button("Cancel") {
                        showTokenSheet = false
                    }
                }
                ToolbarItem(placement: .topBarTrailing) {
                    Button("Sign In") {
                        showTokenSheet = false
                        Task {
                            _ = await authManager.signInWithToken(
                                inputToken,
                                email: inputEmail.isEmpty ? nil : inputEmail
                            )
                        }
                    }
                    .bold()
                    .disabled(inputToken.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
                }
            }
        }
        .presentationDetents([.medium])
    }
}
