import SwiftUI

// MARK: - App Settings & Preferences View

public struct SettingsView: View {
    @ObservedObject private var settings = AppSettings.shared
    @State private var authManager = AuthenticationManager.shared
    @State private var showPaywall: Bool = false
    @State private var showLoginSheet: Bool = false
    @Environment(\.dismiss) private var dismiss

    public init() {}

    public var body: some View {
        NavigationStack {
            List {
                // Account Section
                Section {
                    if authManager.isAuthenticated {
                        if let email = authManager.currentUser?.email, !email.isEmpty {
                            HStack {
                                Text("Email")
                                Spacer()
                                Text(email)
                                    .foregroundStyle(.secondary)
                            }
                        }

                        HStack {
                            Text("Plan")
                            Spacer()
                            Text(authManager.activeAccount?.planType.displayName ?? (authManager.currentUser?.planType.capitalized ?? "Free"))
                                .foregroundStyle(.secondary)
                        }

                        Button(role: .destructive) {
                            Task {
                                await authManager.signOut()
                                dismiss()
                            }
                        } label: {
                            HStack {
                                Spacer()
                                Text("Sign Out")
                                    .font(.body.weight(.semibold))
                                    .foregroundStyle(.red)
                                Spacer()
                            }
                        }
                    } else {
                        VStack(alignment: .leading, spacing: 6) {
                            Text("Signed Out")
                                .font(.headline)
                            Text("Log in to sync your conversation history and access GPT-4o.")
                                .font(.caption)
                                .foregroundStyle(.secondary)
                        }
                        .padding(.vertical, 4)

                        Button {
                            showLoginSheet = true
                        } label: {
                            HStack {
                                Spacer()
                                Text("Sign In")
                                    .font(.body.weight(.semibold))
                                    .foregroundStyle(Color.accentColor)
                                Spacer()
                            }
                        }
                    }
                } header: {
                    Text("Account")
                }

                // Subscription Section
                Section {
                    Button {
                        showPaywall = true
                    } label: {
                        HStack {
                            VStack(alignment: .leading, spacing: 4) {
                                Text("ChatGPT Plus")
                                    .font(.headline)
                                    .foregroundStyle(.purple)
                                Text("Upgrade to access o1 and faster responses")
                                    .font(.subheadline)
                                    .foregroundStyle(.secondary)
                            }

                            Spacer()

                            Image(systemName: "chevron.right")
                                .font(.caption.bold())
                                .foregroundStyle(.secondary)
                        }
                        .padding(.vertical, 4)
                    }
                } header: {
                    Text("Subscription")
                }

                // Voice & Audio Section
                Section {
                    Picker("Voice", selection: $settings.selectedVoice) {
                        ForEach(VoicePreset.allCases) { voice in
                            Text(voice.displayName).tag(voice.rawValue)
                        }
                    }

                    Toggle("Haptic Feedback", isOn: $settings.isHapticsEnabled)
                } header: {
                    Text("Speech & Audio")
                }

                // Data Controls Section
                Section {
                    Toggle("Chat History & Training", isOn: $settings.isHistoryAndTrainingEnabled)

                    Button("Export Data") {
                        // Data export request
                    }

                    Button(role: .destructive) {
                        // Clear chats action
                    } label: {
                        Text("Delete All Chats")
                    }
                } header: {
                    Text("Data Controls")
                } footer: {
                    Text("Save new chats on this device to your history and allow them to be used to improve our models. Unsaved chats will be deleted within 30 days.")
                }

                // App Info Section
                Section {
                    HStack {
                        Text("Version")
                        Spacer()
                        Text("1.2026.300")
                            .foregroundStyle(.secondary)
                    }

                    Link("Terms of Use", destination: URL(string: "https://openai.com/policies/terms-of-use")!)
                    Link("Privacy Policy", destination: URL(string: "https://openai.com/policies/privacy-policy")!)
                } header: {
                    Text("About")
                }
            }
            .navigationTitle("Settings")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    Button("Done") {
                        dismiss()
                    }
                }
            }
            .sheet(isPresented: $showPaywall) {
                SubscriptionPaywallView()
            }
            .sheet(isPresented: $showLoginSheet) {
                LoginView(authManager: authManager) {
                    showLoginSheet = false
                }
            }
        }
    }
}
